const { test, expect } = require('@playwright/test');

const PAGE = `data:text/html,<!doctype html><html><body>
<h1>Checkout</h1>
<form aria-label="Checkout">
  <label>Email address <input type="text" name="email"></label>
  <div role="dialog" aria-label="Confirm payment" id="modal">
    <button id="pay">Pay now</button>
    <button id="cancel">Cancel</button>
  </div>
</form>
<script>
  document.getElementById('pay').addEventListener('click', () => {
    document.getElementById('pay').setAttribute('disabled','');
    document.getElementById('cancel').remove();
  });
</script>
</body></html>`;

test('checkout — cancel is gone after paying', async ({ page }) => {
  await page.goto(PAGE);
  await page.getByRole('textbox', { name: 'Email address' }).fill('a@b.test');
  await page.getByRole('button', { name: 'Pay now' }).click();
  // Pay's handler removed Cancel and disabled Pay — this click times out on the
  // now-mutated page, and its before-snapshot captures that failure state.
  await page.getByRole('button', { name: 'Cancel' }).click({ timeout: 1500 });
});
